package constants;


public class CONSTANTS {
	public static final int WINDOW_WIDTH = 800;
	public static final int WINDOW_HEIGHT = 640;
	public static final int GAME_WIDTH = 1600;
	public static final int GAME_HEIGHT = 600;
	public static final int VEL = 10;
	public static final int SIZE = 20;
	public static final int GAME_ROWS =  GAME_HEIGHT / SIZE;
	public static final int	GAME_COLS = GAME_WIDTH / SIZE;
	public static final String GAME_TITLE = "Shoot'em";	
}